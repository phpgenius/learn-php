Learn PHP - Code Bundle
========================

All 96 lesson code examples, one file per lesson, grouped by level.

Structure
---------
level-1/  Foundations & Syntax        (lessons 1-14)
level-2/  Control Flow                (lessons 15-26)
level-3/  Arrays & Strings            (lessons 27-40)
level-4/  Functions & Reuse           (lessons 41-48)
level-5/  Forms, State & Files        (lessons 49-60)
level-6/  Object-Oriented PHP         (lessons 61-74)
level-7/  MySQL & PDO                 (lessons 75-88)
level-8/  Security & Production       (lessons 89-96)

Running a file
--------------
    php level-1/lesson-01.php

Lesson 2 is a shell script (installing PHP), saved as .sh.

Notes
-----
- These are teaching examples, not production code. Several deliberately
  show the WRONG way first so the fix makes sense.
- Level 7 files expect a MySQL database; connection settings are at the top
  of each file and are placeholders.
- This bundle is illustrative teaching material written for Learn PHP.
