// Lesson 1: What PHP Is and Where It Runs
// Level 1 - Foundations & Syntax
// The request/response model that explains every other PHP behaviour.

<?php
declare(strict_types=1);

// Runs on the server. The browser receives only the result.
echo "Hello from PHP " . PHP_VERSION;

// This line is never sent to the client:
// the browser sees "Hello from PHP 8.3.x" and nothing else.
