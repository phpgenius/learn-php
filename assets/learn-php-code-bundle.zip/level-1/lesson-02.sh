# Check what you have
php -v

# Serve the current folder on port 8000
php -S localhost:8000

# Then open http://localhost:8000/index.php
