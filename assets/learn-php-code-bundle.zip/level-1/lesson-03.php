// Lesson 3: PHP Syntax and Tags
// Level 1 - Foundations & Syntax
// Opening tags, statement terminators, and mixing PHP with HTML.

<?php
declare(strict_types=1);

$title = 'Dashboard';
?>
<!DOCTYPE html>
<html>
<body>
  <h1><?= htmlspecialchars($title) ?></h1>
  <?php if ($title !== ''): ?>
    <p>Rendered by PHP.</p>
  <?php endif; ?>
</body>
</html>
