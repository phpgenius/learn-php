// Lesson 4: Comments and Code Style
// Level 1 - Foundations & Syntax
// Three comment styles, and the PSR-12 habits that make diffs readable.

<?php
declare(strict_types=1);

/**
 * Rounds up to the nearest 0.05 - the smallest coin we accept.
 */
function roundToNickel(float $amount): float
{
    // ceil() avoids the float drift that round() introduces here.
    return ceil($amount * 20) / 20;
}

echo roundToNickel(10.03); // 10.05
