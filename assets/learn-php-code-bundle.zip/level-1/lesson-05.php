// Lesson 5: Variables and Assignment
// Level 1 - Foundations & Syntax
// Naming, reassignment, and why double quotes interpolate.

<?php
declare(strict_types=1);

$name  = "Ada";
$price = 49.5;
$qty   = 3;

$total = $price * $qty;

printf(
    '%s ordered %d licences - total $%.2f' . "\n",
    $name, $qty, $total
);
// Ada ordered 3 licences - total $148.50
