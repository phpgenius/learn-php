// Lesson 6: Variable Scope
// Level 1 - Foundations & Syntax
// Local, global, static and how functions see the outside world.

<?php
declare(strict_types=1);

$counter = 0;

function bump(): int
{
    static $calls = 0;   // survives between calls
    return ++$calls;
}

bump(); bump();
echo bump();   // 3

// $counter is untouched: functions do not see globals.
