// Lesson 7: echo, print and Output
// Level 1 - Foundations & Syntax
// The two output constructs, and when to reach for printf instead.

<?php
declare(strict_types=1);

echo 'a', 'b', 'c', "\n";        // abc
print "one\n";                    // one

$rows = [['SSD', 89.0], ['RAM', 45.5]];
foreach ($rows as [$label, $price]) {
    printf("%-6s %8.2f\n", $label, $price);
}
// SSD       89.00
// RAM       45.50
