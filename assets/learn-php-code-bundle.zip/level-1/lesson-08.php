// Lesson 8: Data Types
// Level 1 - Foundations & Syntax
// The eight types, and what gettype and var_dump actually tell you.

<?php
declare(strict_types=1);

$values = [42, 3.14, 'text', true, null, [1, 2], new stdClass()];

foreach ($values as $v) {
    printf("%-8s %s\n", gettype($v), var_export($v, true));
}
// integer  42
// double   3.14
// string   'text'
// boolean  true
// NULL     NULL
