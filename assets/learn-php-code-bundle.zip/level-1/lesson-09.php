// Lesson 9: Strings
// Level 1 - Foundations & Syntax
// Quoting, length, and the multibyte trap.

<?php
declare(strict_types=1);

$s = 'Hello, world';

echo strlen($s), "\n";        // 12
echo strtoupper($s), "\n";    // HELLO, WORLD
echo ucfirst('php'), "\n";    // Php

$emoji = 'hi';
echo strlen($emoji), "\n";        // 4 bytes
echo mb_strlen($emoji), "\n";     // 2 characters
