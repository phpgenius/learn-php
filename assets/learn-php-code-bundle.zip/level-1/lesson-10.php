// Lesson 10: Numbers and Numeric Strings
// Level 1 - Foundations & Syntax
// Integers, floats, and the comparisons that surprise people.

<?php
declare(strict_types=1);

var_dump(0.1 + 0.2 === 0.3);        // false
var_dump(abs((0.1 + 0.2) - 0.3) < PHP_FLOAT_EPSILON); // true

var_dump('abc' == 0);               // false in PHP 8
var_dump('10' == 10);               // true
var_dump('10' === 10);              // false

echo PHP_INT_MAX;                   // 9223372036854775807
