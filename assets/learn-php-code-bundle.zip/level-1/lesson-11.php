// Lesson 11: Type Casting and Juggling
// Level 1 - Foundations & Syntax
// Explicit casts, and why strict_types changes everything.

<?php
declare(strict_types=1);

var_dump((int) '42abc');    // int(42)
var_dump((bool) '0');       // bool(false)
var_dump((array) 'x');      // array(1) { [0]=> string(1) "x" }
var_dump((string) 3.0);     // string(1) "3"

function add(int $a, int $b): int { return $a + $b; }
// add('1', '2');  // TypeError under strict_types
