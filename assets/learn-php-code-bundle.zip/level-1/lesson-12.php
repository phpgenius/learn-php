// Lesson 12: Math Functions
// Level 1 - Foundations & Syntax
// Rounding, min/max, powers and random numbers done safely.

<?php
declare(strict_types=1);

echo round(3.14159, 2), "\n";        // 3.14
echo floor(3.9), "\n";               // 3
echo ceil(3.1), "\n";                // 4
echo intdiv(17, 5), "\n";            // 3
echo 17 % 5, "\n";                   // 2
echo max([3, 9, 4]), "\n";           // 9

// Cryptographically secure:
echo random_int(100000, 999999);
