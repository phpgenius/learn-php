// Lesson 13: Constants
// Level 1 - Foundations & Syntax
// const vs define, and why constants belong in one place.

<?php
declare(strict_types=1);

const TAX_RATE = 0.2;
const APP_NAME = 'Learn PHP';

define('LEGACY_FLAG', true);   // runtime, global

final class Limits
{
    public const MAX_UPLOAD = 5_242_880;   // 5 MB
}

echo TAX_RATE * 100, "%\n";
echo Limits::MAX_UPLOAD, "\n";
echo PHP_EOL;
