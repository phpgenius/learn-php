// Lesson 14: Operators and Precedence
// Level 1 - Foundations & Syntax
// Arithmetic, assignment, comparison, null coalescing and the spaceship.

<?php
declare(strict_types=1);

$a = null;
echo $a ?? 'fallback', "\n";        // fallback
echo (0 ?: 'zero is falsy'), "\n";  // zero is falsy

var_dump(1 <=> 2);   // int(-1)
var_dump(2 <=> 2);   // int(0)

$total = 10;
$total += 5;  $total *= 2;
echo $total, "\n";   // 30

// Chained null-safe access:
$user = null;
echo $user?->name ?? 'guest';
