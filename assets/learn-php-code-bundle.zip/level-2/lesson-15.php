// Lesson 15: if, else and elseif
// Level 2 - Control Flow
// The three shapes of a conditional and when to invert one.

<?php
declare(strict_types=1);

$score = 82;

if ($score >= 90) {
    $grade = 'A';
} elseif ($score >= 80) {
    $grade = 'B';
} elseif ($score >= 70) {
    $grade = 'C';
} else {
    $grade = 'F';
}

echo "Grade: $grade";   // Grade: B
