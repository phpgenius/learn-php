// Lesson 16: Comparison and Logical Operators in Conditions
// Level 2 - Control Flow
// Truthiness, short-circuiting, and the values that are falsy.

<?php
declare(strict_types=1);

$values = [0, '0', '', [], null, 'false', ' ', 1];
foreach ($values as $v) {
    printf("%-8s %s\n", var_export($v, true), $v ? 'truthy' : 'falsy');
}
// 'false'  truthy
// ' '      truthy
