// Lesson 17: Shorthand if and the Ternary Operator
// Level 2 - Control Flow
// Ternary, elvis, and when a ternary becomes unreadable.

<?php
declare(strict_types=1);

$count = 0;

$label = $count === 1 ? 'item' : 'items';
$name  = $userName ?? 'guest';
$shown = $count ?: 'none';

echo "$count $label\n";   // 0 items
echo "$name\n";           // guest
echo "$shown\n";          // none
