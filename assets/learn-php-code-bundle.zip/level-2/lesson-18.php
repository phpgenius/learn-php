// Lesson 18: Nested Conditionals and Early Returns
// Level 2 - Control Flow
// Flatten logic with guard clauses instead of indenting deeper.

<?php
declare(strict_types=1);

function canPublish(?array $post, bool $isAdmin): bool
{
    if ($post === null)      return false;
    if ($post['draft'] ?? true) return false;
    if (!$isAdmin && !$post['approved']) return false;

    return true;
}

var_dump(canPublish(['draft' => false, 'approved' => true], false)); // true
