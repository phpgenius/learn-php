// Lesson 19: switch Statements
// Level 2 - Control Flow
// Fall-through, strict comparison, and the missing break bug.

<?php
declare(strict_types=1);

$role = 'editor';

switch ($role) {
    case 'admin':
    case 'owner':
        $level = 3;
        break;
    case 'editor':
        $level = 2;
        break;
    default:
        $level = 1;
}

echo $level;   // 2
