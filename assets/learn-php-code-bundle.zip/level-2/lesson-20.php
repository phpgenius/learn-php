// Lesson 20: match Expressions
// Level 2 - Control Flow
// The PHP 8 replacement for switch: strict, an expression, exhaustive.

<?php
declare(strict_types=1);

function statusLabel(int $code): string
{
    return match (true) {
        $code >= 500 => 'server error',
        $code >= 400 => 'client error',
        $code >= 300 => 'redirect',
        $code >= 200 => 'ok',
        default      => 'unknown',
    };
}

echo statusLabel(404);   // client error
