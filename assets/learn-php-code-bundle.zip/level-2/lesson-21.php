// Lesson 21: while Loops
// Level 2 - Control Flow
// Condition-first looping and the infinite loop you will write once.

<?php
declare(strict_types=1);

$i = 1;
while ($i <= 5) {
    echo $i, ' ';
    $i++;          // without this: infinite loop
}
echo "\n";

$queue = ['a', 'b', 'c'];
while ($item = array_shift($queue)) {
    echo $item;
}
