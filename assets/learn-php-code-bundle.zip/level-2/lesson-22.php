// Lesson 22: do-while Loops
// Level 2 - Control Flow
// Run once, then decide - the right shape for retry and menu loops.

<?php
declare(strict_types=1);

$attempts = 0;
do {
    $attempts++;
    $ok = $attempts >= 3;   // pretend the third try succeeds
} while (!$ok && $attempts < 5);

echo "succeeded after $attempts attempts";
