// Lesson 23: for Loops
// Level 2 - Control Flow
// Three-part loops, and iterating backwards or by step.

<?php
declare(strict_types=1);

for ($i = 0; $i < 3; $i++) {
    echo $i, ' ';
}
echo "\n";

$items = ['a', 'b', 'c', 'd'];
for ($i = count($items) - 1; $i >= 0; $i--) {
    echo $items[$i];
}
echo "\n";

for ($i = 0; $i <= 10; $i += 5) {
    echo $i, ' ';
}
