// Lesson 24: foreach Loops
// Level 2 - Control Flow
// Value, key, references, and modifying the array you iterate.

<?php
declare(strict_types=1);

$prices = ['ssd' => 89, 'ram' => 45];

foreach ($prices as $sku => $price) {
    printf("%s: $%d\n", strtoupper($sku), $price);
}

$rows = [[1, 'Ada'], [2, 'Grace']];
foreach ($rows as [$id, $name]) {
    echo "$id $name\n";
}

// By reference - always unset afterwards:
foreach ($prices as &$p) { $p = (int) round($p * 1.1); }
unset($p);
