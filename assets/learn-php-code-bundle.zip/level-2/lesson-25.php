// Lesson 25: break and continue
// Level 2 - Control Flow
// Leaving a loop early, and the level argument nobody remembers.

<?php
declare(strict_types=1);

foreach ([1, 2, 3, 4, 5] as $n) {
    if ($n === 3) continue;   // skip 3
    if ($n === 5) break;      // stop at 5
    echo $n, ' ';
}
echo "\n";   // 1 2 4

foreach ([[1, 2], [3, 4]] as $row) {
    foreach ($row as $v) {
        if ($v === 3) break 2;   // leave both loops
        echo $v, ' ';
    }
}
