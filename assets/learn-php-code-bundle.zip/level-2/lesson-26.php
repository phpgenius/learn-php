// Lesson 26: Loop Patterns and Common Bugs
// Level 2 - Control Flow
// Accumulators, early exit, and the four loop bugs reviewers find.

<?php
declare(strict_types=1);

$orders = [['total' => 20], ['total' => 35], ['total' => 5]];

$sum = 0;                       // outside the loop
$big = [];
foreach ($orders as $o) {
    $sum += $o['total'];
    if ($o['total'] >= 20) {
        $big[] = $o['total'];
    }
}

printf("sum=%d count=%d\n", $sum, count($big));

// Early exit instead of a flag:
foreach ($orders as $o) {
    if ($o['total'] > 30) { echo "found\n"; break; }
}
