// Lesson 27: Indexed Arrays
// Level 3 - Arrays & Strings
// Zero-based lists, appending, and the holes that surprise you.

<?php
declare(strict_types=1);

$fruits = ['apple', 'banana'];
$fruits[] = 'cherry';

echo $fruits[0], "\n";        // apple
echo count($fruits), "\n";    // 3

unset($fruits[1]);
var_dump(array_is_list($fruits));   // false - key 1 is gone

$fruits = array_values($fruits);
var_dump(array_is_list($fruits));   // true
