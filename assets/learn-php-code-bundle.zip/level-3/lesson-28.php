// Lesson 28: Associative Arrays
// Level 3 - Arrays & Strings
// String keys, lookups, and the difference between isset and array_key_exists.

<?php
declare(strict_types=1);

$user = [
    'id'    => 7,
    'name'  => 'Ada',
    'email' => null,
];

echo $user['name'], "\n";
var_dump(isset($user['email']));            // false
var_dump(array_key_exists('email', $user)); // true

$user['role'] = 'admin';
echo count($user), "\n";   // 4
