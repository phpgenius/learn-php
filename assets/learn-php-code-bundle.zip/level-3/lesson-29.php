// Lesson 29: Creating and Accessing Arrays
// Level 3 - Arrays & Strings
// Short syntax, range, list(), and safe access.

<?php
declare(strict_types=1);

$a = [1, 2, 3];
$b = range(1, 5);          // [1,2,3,4,5]
$c = range('a', 'e');      // ['a'..'e']

[$first, $second] = $a;
echo $first, $second, "\n";   // 12

echo $a[9] ?? 'missing', "\n";   // missing
echo count($b), "\n";            // 5
