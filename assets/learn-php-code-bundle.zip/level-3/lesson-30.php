// Lesson 30: Adding, Updating and Removing Elements
// Level 3 - Arrays & Strings
// push, pop, shift, unshift, splice and unset.

<?php
declare(strict_types=1);

$q = ['b', 'c'];
array_unshift($q, 'a');     // ['a','b','c']
array_push($q, 'd');        // ['a','b','c','d']
echo array_shift($q), "\n"; // a
echo array_pop($q), "\n";   // d

$nums = [1, 2, 3, 4, 5];
array_splice($nums, 1, 2, [9, 9]);
print_r($nums);   // [1, 9, 9, 4, 5]
