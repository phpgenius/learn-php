// Lesson 31: Sorting Arrays
// Level 3 - Arrays & Strings
// sort vs asort vs ksort, and sorting by a computed key.

<?php
declare(strict_types=1);

$prices = ['ssd' => 89, 'ram' => 45, 'cpu' => 320];

asort($prices);            // by value, keys kept
print_r($prices);

$people = [
    ['name' => 'Ada',   'age' => 36],
    ['name' => 'Grace', 'age' => 45],
];
usort($people, fn($a, $b) => $b['age'] <=> $a['age']);
echo $people[0]['name'], "\n";   // Grace
