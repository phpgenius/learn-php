// Lesson 32: Multidimensional Arrays
// Level 3 - Arrays & Strings
// Nested data, safe traversal, and flattening.

<?php
declare(strict_types=1);

$orders = [
    ['id' => 1, 'items' => [['sku' => 'A', 'qty' => 2]]],
    ['id' => 2, 'items' => [['sku' => 'B', 'qty' => 1]]],
];

foreach ($orders as $order) {
    foreach ($order['items'] as $item) {
        printf("#%d %s x%d\n", $order['id'], $item['sku'], $item['qty']);
    }
}

echo $orders[0]['items'][0]['sku'] ?? 'n/a', "\n";   // A
