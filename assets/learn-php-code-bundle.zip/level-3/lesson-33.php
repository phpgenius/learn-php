// Lesson 33: Array Functions
// Level 3 - Arrays & Strings
// map, filter, reduce and the ones that replace a foreach.

<?php
declare(strict_types=1);

$nums = [1, 2, 3, 4, 5, 6];

$doubled = array_map(fn($n) => $n * 2, $nums);
$evens   = array_values(array_filter($nums, fn($n) => $n % 2 === 0));
$sum     = array_reduce($nums, fn($c, $n) => $c + $n, 0);

echo implode(',', $doubled), "\n";   // 2,4,6,8,10,12
echo implode(',', $evens), "\n";     // 2,4,6
echo $sum, "\n";                     // 21

$byId = array_column([['id'=>1],['id'=>2]], null, 'id');
