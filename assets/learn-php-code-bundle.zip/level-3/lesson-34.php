// Lesson 34: Array Destructuring and Spread
// Level 3 - Arrays & Strings
// Swapping, skipping, and merging with the spread operator.

<?php
declare(strict_types=1);

[$a, , $c] = [1, 2, 3];
echo "$a $c\n";        // 1 3

[$x, $y] = [$y ?? 0, $x ?? 0];   // swap idiom

$defaults = ['host' => 'localhost', 'port' => 3306];
$config   = [...$defaults, 'port' => 5432];
print_r($config);      // port overridden

$args = [3, 4];
echo max(...$args), "\n";
