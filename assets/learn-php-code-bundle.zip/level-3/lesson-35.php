// Lesson 35: String Functions
// Level 3 - Arrays & Strings
// The twenty functions that cover most real string work.

<?php
declare(strict_types=1);

$s = '  Hello World  ';

echo '[' . trim($s) . "]\n";
echo str_contains($s, 'World') ? "yes\n" : "no\n";
echo str_starts_with(trim($s), 'Hello') ? "yes\n" : "no\n";
echo str_replace('World', 'PHP', $s), "\n";
echo ucwords('ada lovelace'), "\n";
echo str_repeat('-', 10), "\n";
echo str_pad('7', 3, '0', STR_PAD_LEFT), "\n";   // 007
