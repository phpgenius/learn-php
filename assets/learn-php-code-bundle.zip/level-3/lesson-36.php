// Lesson 36: Concatenation and Interpolation
// Level 3 - Arrays & Strings
// The dot operator, complex interpolation, and heredoc.

<?php
declare(strict_types=1);

$user = ['name' => 'Ada'];
$greeting = "Hello, {$user['name']}!";
echo $greeting, "\n";

$msg = <<<TXT
Dear {$user['name']},
Your order shipped.
TXT;
echo $msg, "\n";

$out = 'a' . 'b' . 'c';
$out .= 'd';
echo $out, "\n";   // abcd
