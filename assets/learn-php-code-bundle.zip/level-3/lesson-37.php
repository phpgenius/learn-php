// Lesson 37: Substrings and Slicing
// Level 3 - Arrays & Strings
// substr, negative offsets, and cutting on character boundaries.

<?php
declare(strict_types=1);

$s = 'abcdefgh';

echo substr($s, 0, 3), "\n";    // abc
echo substr($s, -3), "\n";      // fgh
echo substr($s, 2, -2), "\n";   // cdef

$text = 'Café au lait';
echo mb_substr($text, 0, 4), "\n";   // Café
echo substr($text, 0, 4), "\n";      // Caf + broken byte
