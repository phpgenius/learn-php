// Lesson 38: Searching and Replacing in Strings
// Level 3 - Arrays & Strings
// strpos, str_contains, preg_replace and the replace-once trap.

<?php
declare(strict_types=1);

$s = 'The cat sat on the mat.';

echo strpos($s, 'sat'), "\n";            // 8
echo str_replace('cat', 'dog', $s), "\n";
echo str_ireplace('THE', 'a', $s), "\n"; // case-insensitive

$clean = preg_replace('/\s+/', ' ', trim($s));
echo $clean, "\n";

$count = 0;
str_replace('a', 'b', $s, $count);
echo $count, "\n";   // 3
