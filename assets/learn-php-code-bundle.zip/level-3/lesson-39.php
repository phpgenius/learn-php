// Lesson 39: Escape Characters and Heredoc
// Level 3 - Arrays & Strings
// \n, \t, \$, and the three quoting styles.

<?php
declare(strict_types=1);

echo "Tab:\there\n";
echo "Newline:\n";
echo "Literal: \$100\n";
echo 'Literal: $100' . "\n";
echo 'It\'s fine' . "\n";

$name = 'Ada';
$tpl = <<<HTML
<p>Hello, $name</p>
HTML;
echo $tpl, "\n";

$raw = <<<'RAW'
No $interpolation here.
RAW;
echo $raw;
