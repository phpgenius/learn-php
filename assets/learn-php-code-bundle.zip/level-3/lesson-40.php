// Lesson 40: Formatting Output with printf
// Level 3 - Arrays & Strings
// Format specifiers, padding, and building tables in plain text.

<?php
declare(strict_types=1);

$rows = [
    ['SSD 1TB', 89.0, 4],
    ['RAM 16GB', 45.5, 12],
];

printf("%-10s %8s %5s\n", 'ITEM', 'PRICE', 'QTY');
printf("%s\n", str_repeat('-', 25));
foreach ($rows as [$name, $price, $qty]) {
    printf("%-10s %8.2f %5d\n", $name, $price, $qty);
}

printf("Hex: %x  Padded: %05d  Pct: %.1f%%\n", 255, 42, 12.34);
