// Lesson 41: User-Defined Functions
// Level 4 - Functions & Reuse
// Declaring, calling, and the single-responsibility rule.

<?php
declare(strict_types=1);

function slugify(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

echo slugify('Hello, World! 2026');   // hello-world-2026
