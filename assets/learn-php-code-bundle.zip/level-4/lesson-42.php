// Lesson 42: Typed Parameters and Return Types
// Level 4 - Functions & Reuse
// Scalar types, union types, nullable and never.

<?php
declare(strict_types=1);

function area(float $w, float $h): float
{
    return $w * $h;
}

function find(int $id): ?array
{
    return $id === 1 ? ['id' => 1] : null;
}

function fail(string $msg): never
{
    throw new RuntimeException($msg);
}

echo area(2, 3.5), "\n";        // 7
var_dump(find(2));              // NULL
