// Lesson 43: Default, Named and Variadic Arguments
// Level 4 - Functions & Reuse
// Optional parameters, argument unpacking, and PHP 8 named arguments.

<?php
declare(strict_types=1);

function connect(
    string $host = 'localhost',
    int $port = 3306,
    bool $ssl = false
): string {
    return "$host:$port" . ($ssl ? ' (ssl)' : '');
}

echo connect(), "\n";
echo connect(port: 5432), "\n";          // named argument
echo connect('db', 5432, true), "\n";

function sum(int ...$n): int { return array_sum($n); }
echo sum(1, 2, 3, 4), "\n";              // 10
