// Lesson 44: Callback and Arrow Functions
// Level 4 - Functions & Reuse
// Closures, use(), and the one-line fn() syntax.

<?php
declare(strict_types=1);

$rate = 0.2;

$withTax = function (float $n) use ($rate): float {
    return $n * (1 + $rate);
};
echo $withTax(100), "\n";   // 120

$nums = [1, 2, 3];
$sq = array_map(fn($n) => $n ** 2, $nums);
echo implode(',', $sq), "\n";   // 1,4,9

$counter = 0;
$inc = function () use (&$counter) { $counter++; };
$inc(); $inc();
echo $counter, "\n";   // 2
