// Lesson 45: include, require and Autoloading
// Level 4 - Functions & Reuse
// The four include forms, and why require_once is not a design.

<?php
declare(strict_types=1);

// Paths relative to this file, not the CWD:
require __DIR__ . '/config.php';
require __DIR__ . '/lib/helpers.php';

// include 'optional.php';   // warns, keeps going
// require 'critical.php';   // fatal if missing

echo APP_NAME, "\n";
