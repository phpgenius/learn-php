// Lesson 46: Dates and Times
// Level 4 - Functions & Reuse
// DateTimeImmutable, timezones, and formatting for humans.

<?php
declare(strict_types=1);

$utc = new DateTimeImmutable('2026-03-01 12:00:00', new DateTimeZone('UTC'));
$local = $utc->setTimezone(new DateTimeZone('Asia/Manila'));

echo $utc->format('Y-m-d H:i T'), "\n";     // 2026-03-01 12:00 UTC
echo $local->format('Y-m-d H:i T'), "\n";   // 2026-03-01 20:00 PST

$next = $utc->modify('+14 days');
echo $next->format('D, j M Y'), "\n";

$diff = $utc->diff($next);
echo $diff->days, " days\n";
