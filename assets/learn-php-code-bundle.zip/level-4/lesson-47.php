// Lesson 47: JSON Encode and Decode
// Level 4 - Functions & Reuse
// Associative vs object decoding, and the flags that matter.

<?php
declare(strict_types=1);

$data = ['id' => 1, 'tags' => ['php', 'sql'], 'ok' => true];

$json = json_encode($data, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT);
echo $json, "\n";

$back = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
echo $back['tags'][0], "\n";   // php

// API response:
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['status' => 'ok']);
