// Lesson 48: Regular Expressions
// Level 4 - Functions & Reuse
// PCRE basics, delimiters, and the catastrophic backtracking trap.

<?php
declare(strict_types=1);

$zip = '90210';
var_dump((bool) preg_match('/^\d{5}$/', $zip));   // true

preg_match('/^(\d{3})-(\d{4})$/', '555-1234', $m);
echo $m[1], ' / ', $m[2], "\n";   // 555 / 1234

$text = 'a1 b2 c3';
preg_match_all('/[a-z](\d)/', $text, $all);
echo implode(',', $all[1]), "\n";   // 1,2,3

echo preg_replace('/\s+/', '-', 'a  b   c'), "\n";
