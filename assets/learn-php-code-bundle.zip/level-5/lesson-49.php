// Lesson 49: Handling Form Submissions
// Level 5 - Forms, State & Files
// The POST/redirect/GET pattern and why a refresh must not resubmit.

<?php
declare(strict_types=1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if ($email === '') {
        $error = 'Email is required.';
    } else {
        // ... persist ...
        header('Location: /thanks.php', true, 303);
        exit;                       // never forget this
    }
}
?>
<form method="post" action="/subscribe.php">
  <input name="email" type="email" required>
  <button type="submit">Subscribe</button>
</form>
