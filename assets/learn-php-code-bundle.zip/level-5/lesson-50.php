// Lesson 50: Validating Input
// Level 5 - Forms, State & Files
// Required fields, formats, and collecting every error at once.

<?php
declare(strict_types=1);

$errors = [];
$data = [
    'name'  => trim($_POST['name'] ?? ''),
    'email' => trim($_POST['email'] ?? ''),
    'age'   => filter_input(INPUT_POST, 'age', FILTER_VALIDATE_INT),
];

if ($data['name'] === '') {
    $errors['name'] = 'Name is required.';
} elseif (mb_strlen($data['name']) > 80) {
    $errors['name'] = 'Name is too long.';
}

if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Enter a valid email.';
}

if ($data['age'] === false || $data['age'] < 18) {
    $errors['age'] = 'You must be 18 or older.';
}

if ($errors) {
    http_response_code(422);
}
