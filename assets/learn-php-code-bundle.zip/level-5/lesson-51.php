// Lesson 51: Required Fields and Error Messages
// Level 5 - Forms, State & Files
// Field-level errors, repopulation, and accessible markup.

<?php
declare(strict_types=1);

$errors = $errors ?? [];
$old = fn(string $k): string => htmlspecialchars($_POST[$k] ?? '', ENT_QUOTES);
?>
<label for="email">Email</label>
<input id="email" name="email" type="email"
       value="<?= $old('email') ?>"
       aria-invalid="<?= isset($errors['email']) ? 'true' : 'false' ?>"
       aria-describedby="email-err">
<?php if (isset($errors['email'])): ?>
  <p id="email-err" class="err"><?= htmlspecialchars($errors['email']) ?></p>
<?php endif; ?>
