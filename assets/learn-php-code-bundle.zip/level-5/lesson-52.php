// Lesson 52: URL and Email Validation
// Level 5 - Forms, State & Files
// filter_var, IDN domains, and why regex emails fail.

<?php
declare(strict_types=1);

$email = 'ada+php@example.co.uk';
var_dump(filter_var($email, FILTER_VALIDATE_EMAIL) !== false);   // true

$url = 'https://example.com/path?q=1';
var_dump(filter_var($url, FILTER_VALIDATE_URL) !== false);       // true

// Sanitise rather than validate when you just need it clean:
$clean = filter_var('  ada@example.com ', FILTER_SANITIZE_EMAIL);
echo $clean, "\n";
