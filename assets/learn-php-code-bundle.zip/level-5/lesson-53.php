// Lesson 53: Superglobals
// Level 5 - Forms, State & Files
// $_GET, $_POST, $_SERVER, $_FILES, $_SESSION and $_COOKIE.

<?php
declare(strict_types=1);

$page = $_GET['page'] ?? 'home';
$method = $_SERVER['REQUEST_METHOD'];
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Whitelist, never trust:
$allowed = ['home', 'about', 'contact'];
if (!in_array($page, $allowed, true)) {
    $page = 'home';
}

printf("%s %s from %s\n", $method, $page, $ip);
