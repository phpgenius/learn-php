// Lesson 54: $_GET and Query Strings
// Level 5 - Forms, State & Files
// Reading parameters, arrays in the query string, and canonical URLs.

<?php
declare(strict_types=1);

$q    = trim($_GET['q'] ?? '');
$page = max(1, (int) ($_GET['page'] ?? 1));
$tags = $_GET['tag'] ?? [];

if (!is_array($tags)) {
    $tags = [$tags];          // normalise the shape
}

$tags = array_values(array_filter(
    array_map('strval', $tags),
    fn($t) => preg_match('/^[a-z0-9-]{1,20}$/', $t)
));

printf("q=%s page=%d tags=%s\n", $q, $page, implode(',', $tags));
