// Lesson 55: Cookies
// Level 5 - Forms, State & Files
// Setting, reading and the flags that keep a cookie out of the wrong hands.

<?php
declare(strict_types=1);

setcookie('theme', 'dark', [
    'expires'  => time() + 60 * 60 * 24 * 30,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Lax',
]);

$theme = $_COOKIE['theme'] ?? 'light';
$theme = in_array($theme, ['light', 'dark'], true) ? $theme : 'light';

echo $theme;
