// Lesson 56: Sessions
// Level 5 - Forms, State & Files
// session_start, fixation, and what belongs in a session.

<?php
declare(strict_types=1);

session_set_cookie_params([
    'httponly' => true, 'secure' => true, 'samesite' => 'Lax',
]);
session_start();

// On successful login:
$_SESSION['user_id'] = 7;
session_regenerate_id(true);      // stop fixation

// Later:
$userId = $_SESSION['user_id'] ?? null;
if ($userId === null) {
    header('Location: /login.php', true, 303);
    exit;
}
