// Lesson 57: Filters and Sanitisation
// Level 5 - Forms, State & Files
// filter_input, filter_var_array, and validate vs sanitise.

<?php
declare(strict_types=1);

$def = [
    'email' => FILTER_VALIDATE_EMAIL,
    'age'   => ['filter' => FILTER_VALIDATE_INT,
                'options' => ['min_range' => 18, 'max_range' => 120]],
    'name'  => ['filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS],
];

$in = filter_input_array(INPUT_POST, $def) ?? [];

if ($in['email'] === false || $in['age'] === false) {
    http_response_code(422);
    echo 'Invalid input';
} else {
    echo 'ok';
}
