// Lesson 58: File Uploads
// Level 5 - Forms, State & Files
// $_FILES, MIME checks, and storing outside the web root.

<?php
declare(strict_types=1);

$f = $_FILES['doc'] ?? null;
if ($f && $f['error'] === UPLOAD_ERR_OK) {
    if ($f['size'] > 5_242_880) {
        exit('Too large');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png'];

    if (!isset($allowed[$mime])) {
        exit('Unsupported type');
    }

    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    move_uploaded_file($f['tmp_name'], __DIR__ . '/../storage/' . $name);
}
