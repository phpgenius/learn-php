// Lesson 59: Reading and Writing Files
// Level 5 - Forms, State & Files
// file_get_contents, fopen modes, and the locking question.

<?php
declare(strict_types=1);

$path = __DIR__ . '/../storage/log.txt';

file_put_contents($path, "started\n", FILE_APPEND | LOCK_EX);

$lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
echo count($lines), " lines\n";

$fh = fopen($path, 'a');
if ($fh !== false) {
    fwrite($fh, "more\n");
    fclose($fh);
}

// Atomic replace:
file_put_contents($path . '.tmp', "new\n");
rename($path . '.tmp', $path);
