// Lesson 60: Path Safety and Directory Traversal
// Level 5 - Forms, State & Files
// basename, realpath, and the ../ attack.

<?php
declare(strict_types=1);

$root = realpath(__DIR__ . '/../storage');

$requested = $_GET['file'] ?? '';
$target = realpath($root . '/' . basename($requested));

if ($target === false || !str_starts_with($target, $root . DIRECTORY_SEPARATOR)) {
    http_response_code(404);
    exit('Not found');
}

readfile($target);
