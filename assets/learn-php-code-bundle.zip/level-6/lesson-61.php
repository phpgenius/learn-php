// Lesson 61: Classes and Objects
// Level 6 - Object-Oriented PHP
// Properties, methods, and the difference between a class and an instance.

<?php
declare(strict_types=1);

final class Counter
{
    private int $count = 0;

    public function increment(int $by = 1): void
    {
        $this->count += $by;
    }

    public function value(): int
    {
        return $this->count;
    }
}

$c = new Counter();
$c->increment();
$c->increment(4);
echo $c->value();   // 5
