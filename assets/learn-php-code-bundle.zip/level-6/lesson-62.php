// Lesson 62: Constructors and Property Promotion
// Level 6 - Object-Oriented PHP
// __construct, promotion, and validating in one place.

<?php
declare(strict_types=1);

final class Money
{
    public function __construct(
        private readonly int $cents,
        private readonly string $currency = 'USD'
    ) {
        if ($cents < 0) {
            throw new InvalidArgumentException('Negative amount');
        }
    }

    public function format(): string
    {
        return sprintf('%s %.2f', $this->currency, $this->cents / 100);
    }
}

echo (new Money(1999))->format();   // USD 19.99
