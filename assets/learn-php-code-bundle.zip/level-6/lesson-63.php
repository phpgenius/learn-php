// Lesson 63: Destructors
// Level 6 - Object-Oriented PHP
// __destruct, and why you should not rely on it.

<?php
declare(strict_types=1);

final class TempFile
{
    public function __construct(private string $path)
    {
        file_put_contents($this->path, '');
    }

    public function __destruct()
    {
        if (is_file($this->path)) {
            unlink($this->path);
        }
    }
}

$t = new TempFile('/tmp/demo.txt');
unset($t);   // destructor runs here
