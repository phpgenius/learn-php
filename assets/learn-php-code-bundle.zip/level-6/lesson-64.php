// Lesson 64: Access Modifiers
// Level 6 - Object-Oriented PHP
// public, protected, private and the readonly modifier.

<?php
declare(strict_types=1);

class Account
{
    public function __construct(
        private readonly string $id,
        protected int $balance = 0
    ) {}

    public function deposit(int $n): void
    {
        if ($n <= 0) throw new InvalidArgumentException('positive only');
        $this->balance += $n;
    }

    public function balance(): int { return $this->balance; }
}

$a = new Account('acc_1');
$a->deposit(500);
echo $a->balance();   // 500
