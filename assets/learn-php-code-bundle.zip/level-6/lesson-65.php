// Lesson 65: Inheritance
// Level 6 - Object-Oriented PHP
// extends, parent::, and when composition is the better answer.

<?php
declare(strict_types=1);

class Shape
{
    public function __construct(protected string $name) {}

    public function describe(): string
    {
        return "A {$this->name}";
    }
}

final class Circle extends Shape
{
    public function __construct(private float $r)
    {
        parent::__construct('circle');
    }

    public function area(): float
    {
        return M_PI * $this->r ** 2;
    }
}

$c = new Circle(2.0);
echo $c->describe(), ' area=', round($c->area(), 2);
