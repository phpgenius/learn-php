// Lesson 66: Abstract Classes
// Level 6 - Object-Oriented PHP
// Shared implementation with a contract subclasses must fulfil.

<?php
declare(strict_types=1);

abstract class Exporter
{
    public function export(array $rows): string
    {
        $out = $this->header();
        foreach ($rows as $r) {
            $out .= $this->row($r);
        }
        return $out;
    }

    abstract protected function header(): string;
    abstract protected function row(array $r): string;
}

final class CsvExporter extends Exporter
{
    protected function header(): string { return "id,name\n"; }
    protected function row(array $r): string { return "{$r['id']},{$r['name']}\n"; }
}

echo (new CsvExporter())->export([['id' => 1, 'name' => 'Ada']]);
