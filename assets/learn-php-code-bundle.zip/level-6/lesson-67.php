// Lesson 67: Interfaces
// Level 6 - Object-Oriented PHP
// Contracts without implementation, and multiple inheritance of type.

<?php
declare(strict_types=1);

interface Repository
{
    public function find(int $id): ?array;
    public function save(array $row): int;
}

interface Cacheable
{
    public function cacheKey(): string;
}

final class UserRepo implements Repository, Cacheable
{
    public function find(int $id): ?array { return $id === 1 ? ['id' => 1] : null; }
    public function save(array $row): int { return 1; }
    public function cacheKey(): string { return 'user'; }
}

function show(Repository $r): void
{
    var_dump($r->find(1));
}
show(new UserRepo());
