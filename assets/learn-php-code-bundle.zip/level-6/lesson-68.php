// Lesson 68: Traits
// Level 6 - Object-Oriented PHP
// Horizontal reuse, conflict resolution, and the trait smell.

<?php
declare(strict_types=1);

trait Timestamps
{
    private ?DateTimeImmutable $createdAt = null;

    public function touch(): void
    {
        $this->createdAt = new DateTimeImmutable();
    }

    public function createdAt(): ?string
    {
        return $this->createdAt?->format('c');
    }
}

final class Post
{
    use Timestamps;
}

$p = new Post();
$p->touch();
echo $p->createdAt();
