// Lesson 69: Static Methods and Properties
// Level 6 - Object-Oriented PHP
// Class-level state, and why static is hard to test.

<?php
declare(strict_types=1);

final class Str
{
    public static function slug(string $s): string
    {
        return trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($s)), '-');
    }

    public static function random(int $len = 16): string
    {
        return substr(bin2hex(random_bytes($len)), 0, $len);
    }
}

echo Str::slug('Hello World'), "\n";   // hello-world
echo strlen(Str::random(8)), "\n";     // 8
