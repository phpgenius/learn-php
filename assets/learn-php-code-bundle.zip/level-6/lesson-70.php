// Lesson 70: Namespaces and Autoloading
// Level 6 - Object-Oriented PHP
// PSR-4, use statements, and resolving class names.

<?php
declare(strict_types=1);

namespace App\\Domain;

use App\\Support\\Clock;
use InvalidArgumentException;

final class Subscription
{
    public function __construct(
        private Clock $clock,
        private \\DateTimeImmutable $start
    ) {}

    public function isActive(): bool
    {
        return $this->start <= $this->clock->now();
    }
}

// composer.json:
// "autoload": { "psr-4": { "App\\\\": "src/" } }
