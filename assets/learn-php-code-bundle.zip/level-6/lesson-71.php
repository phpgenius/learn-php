// Lesson 71: Iterables and Generators
// Level 6 - Object-Oriented PHP
// Iterator, Traversable, and yielding instead of building an array.

<?php
declare(strict_types=1);

function lines(string $path): Generator
{
    $fh = fopen($path, 'r');
    try {
        while (($line = fgets($fh)) !== false) {
            yield rtrim($line, "\\r\\n");
        }
    } finally {
        fclose($fh);
    }
}

function numbers(int $max): Generator
{
    for ($i = 1; $i <= $max; $i++) {
        yield $i => $i * $i;
    }
}

foreach (numbers(3) as $k => $v) {
    echo "$k=>$v ";
}
