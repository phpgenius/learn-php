// Lesson 72: Enums
// Level 6 - Object-Oriented PHP
// Backed enums, cases, and replacing magic strings.

<?php
declare(strict_types=1);

enum Status: string
{
    case Draft   = 'draft';
    case Review  = 'review';
    case Published = 'published';

    public function label(): string
    {
        return match ($this) {
            self::Draft     => 'Draft',
            self::Review    => 'In review',
            self::Published => 'Live',
        };
    }

    public static function fromInput(string $v): self
    {
        return self::tryFrom($v) ?? self::Draft;
    }
}

echo Status::from('review')->label(), "\n";   // In review
echo Status::Published->value, "\n";          // published
