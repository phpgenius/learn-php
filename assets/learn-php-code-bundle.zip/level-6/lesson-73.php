// Lesson 73: Exceptions in OOP
// Level 6 - Object-Oriented PHP
// Custom exception classes and catching by type.

<?php
declare(strict_types=1);

class PaymentFailed extends RuntimeException {}

final class Gateway
{
    public function charge(int $cents): void
    {
        if ($cents <= 0) {
            throw new PaymentFailed('Amount must be positive');
        }
    }
}

try {
    (new Gateway())->charge(0);
} catch (PaymentFailed $e) {
    echo 'declined: ', $e->getMessage(), "\n";
} finally {
    echo "cleanup\n";
}
