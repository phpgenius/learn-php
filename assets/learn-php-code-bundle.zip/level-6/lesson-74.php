// Lesson 74: Composition and Dependency Injection
// Level 6 - Object-Oriented PHP
// Constructor injection, and why new inside a class hurts.

<?php
declare(strict_types=1);

interface Mailer { public function send(string $to, string $body): bool; }

final class SmtpMailer implements Mailer
{
    public function send(string $to, string $body): bool { return true; }
}

final class Signup
{
    public function __construct(private Mailer $mailer) {}

    public function handle(string $email): void
    {
        $this->mailer->send($email, 'Welcome');
    }
}

(new Signup(new SmtpMailer()))->handle('a@b.co');
