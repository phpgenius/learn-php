// Lesson 76: Creating a Database and Tables
// Level 7 - MySQL & PDO
// DDL, column types, and the constraints that prevent bad data.

<?php
declare(strict_types=1);

$pdo->exec("CREATE DATABASE IF NOT EXISTS shop
            CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email      VARCHAR(255) NOT NULL UNIQUE,
    name       VARCHAR(80)  NOT NULL,
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");
