// Lesson 77: Inserting Rows
// Level 7 - MySQL & PDO
// Prepared inserts, lastInsertId, and batch inserts.

<?php
declare(strict_types=1);

$stmt = $pdo->prepare(
    'INSERT INTO users (email, name) VALUES (:email, :name)'
);

$stmt->execute([':email' => 'ada@example.com', ':name' => 'Ada']);
$id = (int) $pdo->lastInsertId();
echo "inserted $id\n";

// Batch, inside a transaction:
$pdo->beginTransaction();
foreach ([['a@x.co', 'A'], ['b@x.co', 'B']] as [$e, $n]) {
    $stmt->execute([':email' => $e, ':name' => $n]);
}
$pdo->commit();
