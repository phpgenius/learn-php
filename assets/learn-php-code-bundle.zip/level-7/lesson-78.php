// Lesson 78: Prepared Statements
// Level 7 - MySQL & PDO
// Named and positional placeholders, and what cannot be bound.

<?php
declare(strict_types=1);

// Positional
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([7]);

// Named, with explicit types
$stmt = $pdo->prepare('SELECT * FROM users WHERE email = :e AND active = :a');
$stmt->bindValue(':e', 'ada@example.com', PDO::PARAM_STR);
$stmt->bindValue(':a', 1, PDO::PARAM_INT);
$stmt->execute();

// Whitelisted identifier - the only safe interpolation:
$sort = in_array($_GET['sort'] ?? '', ['name', 'created_at'], true)
    ? $_GET['sort'] : 'created_at';
$sql = "SELECT * FROM users ORDER BY $sort DESC";
