// Lesson 79: Selecting and Filtering
// Level 7 - MySQL & PDO
// fetch, fetchAll, fetchColumn and the memory difference.

<?php
declare(strict_types=1);

$stmt = $pdo->prepare('SELECT id, name FROM users WHERE active = :a');
$stmt->execute([':a' => 1]);

while ($row = $stmt->fetch()) {
    echo $row['id'], ' ', $row['name'], "\n";
}

$count = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
echo "total $count\n";

$one = $pdo->query('SELECT * FROM users LIMIT 1')->fetch();
var_dump($one === false);   // true when empty
