// Lesson 80: WHERE, ORDER BY and LIMIT
// Level 7 - MySQL & PDO
// Parameterised filters, sorting, and pagination that scales.

<?php
declare(strict_types=1);

$where = ['active = :active'];
$bind  = [':active' => 1];

if (!empty($_GET['q'])) {
    $where[] = 'name LIKE :q';
    $bind[':q'] = '%' . $_GET['q'] . '%';
}

$sql = 'SELECT * FROM users WHERE ' . implode(' AND ', $where)
     . ' ORDER BY created_at DESC LIMIT :lim OFFSET :off';

$stmt = $pdo->prepare($sql);
foreach ($bind as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue(':lim', 20, PDO::PARAM_INT);
$stmt->bindValue(':off', 0, PDO::PARAM_INT);
$stmt->execute();
