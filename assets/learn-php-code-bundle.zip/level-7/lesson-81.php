// Lesson 81: Updating and Deleting
// Level 7 - MySQL & PDO
// Affected rows, soft deletes, and the missing WHERE clause.

<?php
declare(strict_types=1);

$stmt = $pdo->prepare(
    'UPDATE users SET name = :n WHERE id = :id'
);
$stmt->execute([':n' => 'Ada L.', ':id' => 7]);

if ($stmt->rowCount() === 0) {
    echo "nothing changed - wrong id or same value\n";
}

// Soft delete:
$pdo->prepare('UPDATE users SET deleted_at = NOW() WHERE id = :id')
    ->execute([':id' => 7]);

// Hard delete, always with a WHERE:
$pdo->prepare('DELETE FROM sessions WHERE expires_at < :now')
    ->execute([':now' => date('Y-m-d H:i:s')]);
