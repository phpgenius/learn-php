// Lesson 82: Transactions
// Level 7 - MySQL & PDO
// beginTransaction, commit, rollback and the try/catch shape.

<?php
declare(strict_types=1);

$pdo->beginTransaction();
try {
    $pdo->prepare('UPDATE accounts SET balance = balance - :n WHERE id = :id')
        ->execute([':n' => 100, ':id' => 1]);

    $pdo->prepare('UPDATE accounts SET balance = balance + :n WHERE id = :id')
        ->execute([':n' => 100, ':id' => 2]);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    throw $e;
}
