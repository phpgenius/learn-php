// Lesson 83: Joins and Relationships
// Level 7 - MySQL & PDO
// INNER vs LEFT JOIN, and the N+1 query problem.

<?php
declare(strict_types=1);

$sql = 'SELECT p.id, p.title, u.name AS author
        FROM posts p
        INNER JOIN users u ON u.id = p.user_id
        WHERE p.published = 1
        ORDER BY p.created_at DESC
        LIMIT 20';

foreach ($pdo->query($sql) as $row) {
    echo $row['title'], ' by ', $row['author'], "\n";
}

// LEFT JOIN keeps posts with no comments:
$sql2 = 'SELECT p.id, COUNT(c.id) AS n
         FROM posts p
         LEFT JOIN comments c ON c.post_id = p.id
         GROUP BY p.id';
