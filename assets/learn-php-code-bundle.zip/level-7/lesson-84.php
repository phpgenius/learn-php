// Lesson 84: Indexes and Query Performance
// Level 7 - MySQL & PDO
// EXPLAIN, composite index order, and the leading-wildcard trap.

<?php
declare(strict_types=1);

$pdo->exec('CREATE INDEX idx_posts_user_created
            ON posts (user_id, created_at)');

$rows = $pdo->query('EXPLAIN SELECT * FROM posts
                     WHERE user_id = 1
                     ORDER BY created_at DESC')->fetchAll();

foreach ($rows as $r) {
    echo $r['type'], ' ', $r['key'] ?? 'none', "\n";
}
