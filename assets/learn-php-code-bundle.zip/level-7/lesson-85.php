// Lesson 85: Migrations and Schema Changes
// Level 7 - MySQL & PDO
// Versioned, reversible, and safe to run on a live table.

<?php
declare(strict_types=1);

// migrations/2026_03_01_add_status_to_posts.php
return new class {
    public function up(PDO $pdo): void
    {
        $pdo->exec("ALTER TABLE posts
                    ADD COLUMN status VARCHAR(20) NULL");
        $pdo->exec("UPDATE posts SET status = 'published'
                    WHERE published = 1");
        $pdo->exec("ALTER TABLE posts
                    MODIFY status VARCHAR(20) NOT NULL
                    DEFAULT 'draft'");
    }

    public function down(PDO $pdo): void
    {
        $pdo->exec('ALTER TABLE posts DROP COLUMN status');
    }
};
