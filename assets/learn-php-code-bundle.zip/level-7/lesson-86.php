// Lesson 86: Connection Management and Pooling
// Level 7 - MySQL & PDO
// One connection per request, and why persistent connections bite.

<?php
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;          // one per request
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $pdo = new PDO(
        'mysql:host=127.0.0.1;dbname=shop;charset=utf8mb4',
        getenv('DB_USER'),
        getenv('DB_PASS'),
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    return $pdo;
}

db()->query('SELECT 1');
