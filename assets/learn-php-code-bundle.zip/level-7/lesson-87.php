// Lesson 87: XML and SimpleXML
// Level 7 - MySQL & PDO
// Parsing untrusted XML, and the entity-expansion attack.

<?php
declare(strict_types=1);

$xml = <<<XML
<catalog>
  <book id="1"><title>PHP</title><price>29.00</price></book>
  <book id="2"><title>SQL</title><price>34.00</price></book>
</catalog>
XML;

$sx = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET);
foreach ($sx->book as $b) {
    printf("%s - $%s\n", (string) $b->title, (string) $b->price);
}

echo (string) $sx->book[0]['id'], "\n";   // 1
