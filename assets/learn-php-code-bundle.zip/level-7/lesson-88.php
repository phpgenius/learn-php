// Lesson 88: AJAX and JSON Endpoints
// Level 7 - MySQL & PDO
// A small JSON API, status codes, and CSRF on state changes.

<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }

    $body = json_decode(file_get_contents('php://input'), true, 512, JSON_THROW_ON_ERROR);

    if (empty($body['q'])) {
        http_response_code(422);
        echo json_encode(['error' => 'q is required']);
        exit;
    }

    echo json_encode(['results' => [], 'q' => $body['q']]);
} catch (JsonException $e) {
    http_response_code(400);
    echo json_encode(['error' => 'Malformed JSON']);
}
