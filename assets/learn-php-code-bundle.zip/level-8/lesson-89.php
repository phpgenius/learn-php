// Lesson 89: Cross-Site Scripting and Escaping
// Level 8 - Security & Production
// htmlspecialchars on output, and the contexts that need more.

<?php
declare(strict_types=1);

function e(?string $s): string
{
    return htmlspecialchars($s ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$comment = '<script>alert(1)</script>';

echo '<p>' . e($comment) . '</p>';
// &lt;script&gt;alert(1)&lt;/script&gt;

// In an attribute:
echo '<input value="' . e($comment) . '">';

// In a script block, use json_encode, not htmlspecialchars:
$data = ['name' => $comment];
echo '<script>const d = ' . json_encode($data, JSON_HEX_TAG) . ';</script>';
