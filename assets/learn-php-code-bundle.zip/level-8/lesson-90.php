// Lesson 90: CSRF Protection
// Level 8 - Security & Production
// Synchroniser tokens, SameSite, and why GET must not mutate.

<?php
declare(strict_types=1);

session_start();

function csrf(): string
{
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
}

function verifyCsrf(?string $t): void
{
    if (!is_string($t) || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        http_response_code(419);
        exit('CSRF token mismatch');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf($_POST['_token'] ?? null);
    // ... handle ...
}
?>
<form method="post">
  <input type="hidden" name="_token" value="<?= csrf() ?>">
  <button>Save</button>
</form>
