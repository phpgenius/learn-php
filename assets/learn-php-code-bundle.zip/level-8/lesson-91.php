// Lesson 91: Password Hashing
// Level 8 - Security & Production
// password_hash, password_verify, and rehashing on login.

<?php
declare(strict_types=1);

$hash = password_hash('correct horse', PASSWORD_DEFAULT);
echo $hash, "\n";   // $2y$10$...

var_dump(password_verify('correct horse', $hash));   // true
var_dump(password_verify('wrong', $hash));           // false

// On successful login:
if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
    $new = password_hash('correct horse', PASSWORD_DEFAULT);
    // ... update the row ...
}
