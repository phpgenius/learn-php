// Lesson 92: Session Hardening
// Level 8 - Security & Production
// Cookie flags, regeneration, timeouts and storage.

<?php
declare(strict_types=1);

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

// Idle timeout
$idle = 1800;
if (isset($_SESSION['last']) && time() - $_SESSION['last'] > $idle) {
    session_unset();
    session_destroy();
}
$_SESSION['last'] = time();

// Logout
function logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}
