// Lesson 93: Upload Safety and File Permissions
// Level 8 - Security & Production
// Executable uploads, chmod, and serving files through PHP.

<?php
declare(strict_types=1);

// Serve an upload through PHP, with an auth check.
$root = realpath(__DIR__ . '/../storage');
$name = basename($_GET['f'] ?? '');
$path = realpath($root . '/' . $name);

if ($path === false || !str_starts_with($path, $root . DIRECTORY_SEPARATOR)) {
    http_response_code(404);
    exit;
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
readfile($path);
