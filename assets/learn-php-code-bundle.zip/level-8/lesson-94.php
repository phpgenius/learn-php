// Lesson 94: Exceptions and Error Handling
// Level 8 - Security & Production
// set_exception_handler, error_reporting, and never showing traces.

<?php
declare(strict_types=1);

$isProd = getenv('APP_ENV') === 'production';

ini_set('display_errors', $isProd ? '0' : '1');
ini_set('log_errors', '1');
error_reporting(E_ALL);

set_exception_handler(function (Throwable $e) use ($isProd): void {
    error_log(sprintf('[%s] %s in %s:%d',
        get_class($e), $e->getMessage(), $e->getFile(), $e->getLine()));

    http_response_code(500);
    if ($isProd) {
        echo 'Something went wrong.';
    } else {
        echo '<pre>' . htmlspecialchars((string) $e) . '</pre>';
    }
});
