// Lesson 95: Configuration and Secrets
// Level 8 - Security & Production
// Environment variables, .env files, and what never goes in git.

<?php
declare(strict_types=1);

// Minimal .env loader (or use vlucas/phpdotenv)
$env = __DIR__ . '/../.env';
if (is_file($env)) {
    foreach (file($env, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        [$k, $v] = array_pad(explode('=', $line, 2), 2, '');
        if ($k !== '' && getenv(trim($k)) === false) {
            putenv(trim($k) . '=' . trim($v, " \"'"));
        }
    }
}

$dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4',
    getenv('DB_HOST') ?: '127.0.0.1',
    getenv('DB_NAME') ?: 'shop');
