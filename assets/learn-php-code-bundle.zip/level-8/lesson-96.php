// Lesson 96: Deployment and Production Checklist
// Level 8 - Security & Production
// The last mile: opcache, HTTPS, backups, and a rollback plan.

<?php
declare(strict_types=1);

// production bootstrap
date_default_timezone_set('UTC');
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', '/var/log/php/app.log');

// opcache (php.ini):
// opcache.enable=1
// opcache.validate_timestamps=0   (deploy = restart)
// opcache.memory_consumption=128

// Force HTTPS behind a proxy:
if (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') !== 'https') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], true, 301);
    exit;
}

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
